# CF-BC-03 본인인증 공통 모듈 (identity-common) — 샘플

REQ-AP-601 "휴대폰 본인인증 NICE ID 도입"을 **기존 NICE ID 개발과 별개의 공통모듈**로 분리한 샘플입니다.
적용 채널: APP / PC WEB / 모집인WEB (ADMIN, Batch 제외)

## 1. 설계 핵심

| 원칙 | 구현 |
|---|---|
| 인증수단 교체/추가 시 업무화면 무수정 | `IdentityProvider` SPI (전략 패턴) + `IdentityProviderRegistry` 자동 수집 |
| 흐름과 연동의 분리 | 흐름(거래·검증·세션) = `IdentityVerificationService`, 인증기관 통신 = Provider |
| 화면은 인증기관을 모름 | `/start` 가 form 정보(actionUrl, params)만 반환 → 공통 JS 가 submit |
| 결과는 표준 모델 하나 | `VerifiedIdentity` (CI/DI/성명/생년월일/휴대폰…) |
| NICE 계약 전에도 개발 가능 | `local` 프로필 = `MockIdentityProvider` |

## 2. 패키지 구조

```
com.demo.common.identity
├─ config/      IdentityProperties(yml 바인딩), IdentityConfig(RestClient, Clock)
├─ domain/      AuthMethod, AuthChannel, AuthPurpose, StartRequest/Response,
│               IdentityTx(진행거래), VerifiedIdentity(결과), TermsDocument
├─ spi/         IdentityProvider  ← 인증수단 확장 포인트
├─ provider/
│   ├─ nice/    NiceIdProvider(흐름), NiceApiClient(HTTP), NiceCrypto(암복호화)
│   ├─ mock/    MockIdentityProvider (local 전용)
│   └─ privatecert/ PrivateCertProvider (사설인증 확장 골격)
├─ store/       IdentityTxStore + InMemory 구현 (다중 WAS → Redis 로 교체)
├─ service/     IdentityVerificationService(Facade), IdentitySessionManager,
│               TermsService, IdentityProviderRegistry
├─ exception/   IdentityErrorCode(IDV-xxx), IdentityVerificationException
└─ web/         IdentityVerificationController, IdentityApiExceptionHandler

resources/static/js/common/identity-auth.js      화면 공통 JS
webapp/WEB-INF/views/common/identity/callback.jsp 결과 전달(팝업 postMessage / APP redirect)
webapp/WEB-INF/views/sample/identity-sample.jsp   업무 화면 사용 예시
```

## 3. 처리 흐름

```
[업무화면] IdentityAuth.open()
   │ (팝업 채널: 빈 팝업 먼저 오픈 → 팝업차단 회피)
   ▼
POST /common/identity/start
   ├ 필수약관 동의 재검증 / returnUrl 화이트리스트(APP)
   ├ 거래번호 생성 (IDV+yyyyMMddHHmmss+랜덤10)
   ├ NiceIdProvider.prepare: 암호화토큰 발급 → 대칭키 생성 → enc_data, integrity_value
   └ 거래(대칭키 포함) TxStore 저장  →  form 정보 응답
   ▼
NICE 표준창 (성명+생년월일+휴대폰, 통신사 미지정 / MO인증)
   ▼
GET /common/identity/callback/nice_mobile
   ├ token_version_id 로 거래 1회성 조회(consume) → 재전송 차단
   ├ 만료 / 세션 일치 검증
   ├ HMAC 무결성 → 복호화 → resultcode=0000 → requestno 일치
   ├ VerifiedIdentity 세션 저장(목적별) + 세션ID 재발급
   └ callback.jsp: 팝업 → opener.postMessage + close / APP → returnUrl 이동
   ▼
[업무 API] identitySessionManager.require(session, AuthPurpose.SIGN_UP).ci()
```

## 4. 업무 개발자 사용법 (2단계)

**화면 (JSP)**
```html
<script src="/js/common/identity-auth.js"></script>
<script>
IdentityAuth.open({ method:'NICE_MOBILE', channel:'PC_WEB', purpose:'SIGN_UP',
                    agreedTerms:[...], returnUrl:'/member/join/step2' })
  .then(r => { if (r.success) { /* 다음 단계 */ } else alert(r.message); });
</script>
```

**서버 (업무 Controller/Service)**
```java
VerifiedIdentity idv = identitySessionManager.require(session, AuthPurpose.SIGN_UP); // 미인증 → IDV-301
memberService.join(form, idv.ci(), idv.di(), idv.mobileNo());
identitySessionManager.clear(session, AuthPurpose.SIGN_UP);   // 1회 사용 후 제거
```

## 5. 요구사항 매핑

| 요구사항 (CF-BC-03 / REQ-AP-601) | 반영 위치 |
|---|---|
| NICE ID 휴대폰 본인인증(성명+생년월일+휴대폰) | `NiceIdProvider`, `NiceApiClient`, `NiceCrypto` |
| 통신사 미지정 / MO인증 결합 시 번호입력 생략 | `common.identity.nice.extra-request-params` (NICE 상품 옵션값 설정) |
| 사설인증(통신사·민간) | `PrivateCertProvider` 골격 (SPI 구현만 추가) |
| 인증 결과 CI 획득 및 Session 반영 | `IdentityVerificationService.complete`, `IdentitySessionManager` |
| 인증별 약관 상세보기 / 비여신금융거래 약관 추가 | `TermsService`, `GET /common/identity/terms`, yml `terms` |
| AS-IS 통신사 선택 필수 → TO-BE 불필요 | 통신사 선택 UI·파라미터 없음, 통신사 무관 약관 구성 |

## 6. 실행

```bash
mvn spring-boot:run                       # 기본 local 프로필 = Mock 인증
# http://localhost:8080/sample/identity
mvn test                                  # 단위(NiceCrypto, NiceIdProvider) + 통합(MockMvc 전체 흐름)
```
운영/개발계: `--spring.profiles.active=prd` + 환경변수 `NICE_CLIENT_ID`, `NICE_CLIENT_SECRET`, `NICE_PRODUCT_ID`, (`NICE_ACCESS_TOKEN`), `IDENTITY_BASE_URL`.

## 7. 적용 전 확인 체크리스트 ⚠️

1. **NICE 가이드 대조** — API URL, 헤더(`ProductID`), 요청 필드명, 결과코드표, 응답 문자셋(EUC-KR)은 개발가이드 기준 일반 사양으로 작성했습니다. 계약 시 수령한 최신 가이드와 반드시 대조하세요.
2. **통신사 미지정 / MO인증 옵션** — 상품 계약 옵션입니다. NICE 가 안내하는 파라미터명·값을 `extra-request-params` 에 넣으세요. (소스 수정 불필요)
3. **이중화 환경** — `InMemoryIdentityTxStore` 는 단일 서버용입니다. Redis 구현체(`GETDEL` + TTL)를 `@Primary` 로 등록하세요.
4. **SameSite 쿠키** — 기본 `methodtype=get` 으로 Lax 쿠키가 유지됩니다. `post` 로 바꾸면 세션 쿠키를 `SameSite=None; Secure` 로 설정해야 세션 검증이 통과합니다.
5. **Spring Security** — `/common/identity/callback/**` 는 permitAll + CSRF 예외, `/start` 는 CSRF 토큰 헤더 추가.
6. **Mock 운영 차단** — `mock-enabled=true` 가 운영 프로필에 들어가지 않도록 기동 체크를 추가하세요.
7. **개인정보** — CI 는 DB 저장 시 암호화 컬럼, 로그에는 마스킹(`VerifiedIdentity.toString`)만 남습니다. 감사로그는 `AUDIT.IDENTITY` 로거로 분리되어 있습니다.
8. **APP 연동** — 결과 전달을 returnUrl 이동 대신 네이티브 브릿지로 할 경우 `callback.jsp` 의 브릿지 주석 부분을 앱팀과 협의해 활성화하세요.
