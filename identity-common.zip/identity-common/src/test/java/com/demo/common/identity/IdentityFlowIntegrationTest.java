package com.demo.common.identity;

import com.demo.DemoApplication;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * 전체 흐름 통합 테스트 (local 프로필 = MockIdentityProvider).
 * 시작 → 콜백 → 세션 반영 → 결과 조회 → 업무 API 사용 / 재전송·세션불일치·약관미동의 차단
 */
@SpringBootTest(classes = DemoApplication.class)
@AutoConfigureMockMvc
@ActiveProfiles("local")
class IdentityFlowIntegrationTest {

    private static final String ALL_TERMS =
            "[\"NICE_PRIVACY\",\"NICE_UNIQUE_ID\",\"NICE_SERVICE\",\"NICE_CARRIER\",\"NICE_NON_CREDIT\"]";

    @Autowired MockMvc mvc;
    @Autowired ObjectMapper om;

    private String startBody(String channel, String terms) {
        return "{\"method\":\"NICE_MOBILE\",\"channel\":\"" + channel + "\",\"purpose\":\"SIGN_UP\","
                + "\"returnUrl\":\"/sample/identity\",\"agreedTerms\":" + terms + "}";
    }

    private JsonNode start(MockHttpSession session, String channel) throws Exception {
        MvcResult r = mvc.perform(post("/common/identity/start").session(session)
                        .contentType(MediaType.APPLICATION_JSON).content(startBody(channel, ALL_TERMS)))
                .andExpect(status().isOk()).andReturn();
        return om.readTree(r.getResponse().getContentAsString());
    }

    @Test
    void 정상흐름_팝업채널() throws Exception {
        MockHttpSession session = new MockHttpSession();
        JsonNode s = start(session, "PC_WEB");
        String mockTx = s.path("formParams").path("mock_tx").asText();

        mvc.perform(get("/common/identity/callback/nice_mobile").session(session).param("mock_tx", mockTx))
                .andExpect(view().name("common/identity/callback"))
                .andExpect(model().attribute("success", true))
                .andExpect(model().attribute("popup", true));

        // 결과 조회: 마스킹 확인, CI 미노출
        mvc.perform(get("/common/identity/result").session(session).param("purpose", "SIGN_UP"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("홍*동"))
                .andExpect(jsonPath("$.mobileNo").value("010****5678"))
                .andExpect(jsonPath("$.ci").doesNotExist());

        // 업무 API 1회 사용 후 소멸
        mvc.perform(post("/sample/join").session(session)).andExpect(jsonPath("$.result").value("OK"));
        mvc.perform(post("/sample/join").session(session))
                .andExpect(status().isUnauthorized()).andExpect(jsonPath("$.code").value("IDV-301"));

        // 같은 콜백 재전송 → 거래 없음
        mvc.perform(get("/common/identity/callback/nice_mobile").session(session).param("mock_tx", mockTx))
                .andExpect(model().attribute("success", false))
                .andExpect(model().attribute("errorCode", "IDV-101"));
    }

    @Test
    void APP채널은_returnUrl로_돌아간다() throws Exception {
        MockHttpSession session = new MockHttpSession();
        JsonNode s = start(session, "APP");
        mvc.perform(get("/common/identity/callback/nice_mobile").session(session)
                        .param("mock_tx", s.path("formParams").path("mock_tx").asText()))
                .andExpect(model().attribute("popup", false))
                .andExpect(model().attribute("returnUrl", "/sample/identity"));
    }

    @Test
    void 다른_세션으로_콜백하면_거부() throws Exception {
        JsonNode s = start(new MockHttpSession(), "PC_WEB");
        mvc.perform(get("/common/identity/callback/nice_mobile").session(new MockHttpSession())
                        .param("mock_tx", s.path("formParams").path("mock_tx").asText()))
                .andExpect(model().attribute("success", false))
                .andExpect(model().attribute("errorCode", "IDV-103"));
    }

    @Test
    void 필수약관_미동의시_시작불가() throws Exception {
        mvc.perform(post("/common/identity/start").session(new MockHttpSession())
                        .contentType(MediaType.APPLICATION_JSON).content(startBody("PC_WEB", "[\"NICE_PRIVACY\"]")))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("IDV-002"));
    }

    @Test
    void 외부도메인_returnUrl_차단() throws Exception {
        String body = startBody("APP", ALL_TERMS).replace("/sample/identity", "//evil.com");
        mvc.perform(post("/common/identity/start").session(new MockHttpSession())
                        .contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("IDV-003"));
    }

    @Test
    void 약관목록_조회() throws Exception {
        mvc.perform(get("/common/identity/terms").param("method", "NICE_MOBILE"))
                .andExpect(jsonPath("$[4].title").value("비여신금융거래 약관"));
    }
}
