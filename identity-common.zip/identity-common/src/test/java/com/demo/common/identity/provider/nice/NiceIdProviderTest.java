package com.demo.common.identity.provider.nice;

import com.demo.common.identity.config.IdentityProperties;
import com.demo.common.identity.domain.*;
import com.demo.common.identity.exception.IdentityErrorCode;
import com.demo.common.identity.exception.IdentityVerificationException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * NiceIdProvider 단위 테스트.
 * NICE API 는 Mockito 로 대체하고, "NICE 가 보내줄 암호화 콜백"을 테스트에서 직접 만들어 complete() 를 검증한다.
 */
class NiceIdProviderTest {

    private final Clock clock = Clock.fixed(Instant.parse("2026-10-18T03:00:00Z"), ZoneId.of("Asia/Seoul"));
    private final ObjectMapper om = new ObjectMapper();
    private NiceIdProvider provider;

    @BeforeEach
    void setUp() {
        NiceApiClient api = mock(NiceApiClient.class);
        when(api.requestCryptoToken(anyString(), anyString()))
                .thenReturn(new NiceApiClient.CryptoToken("SITE01", "TVID-001", "tokenVal"));
        IdentityProperties props = new IdentityProperties();
        props.getNice().getExtraRequestParams().put("sampleoption", "Y");
        provider = new NiceIdProvider(api, props, om, clock);
    }

    private StartRequest req(AuthChannel ch) {
        return new StartRequest(AuthMethod.NICE_MOBILE, ch, AuthPurpose.SIGN_UP, null, List.of(), Map.of());
    }

    private IdentityTx txFrom(String txId, ProviderPrepareResult p) {
        return new IdentityTx(txId, p.correlationKey(), AuthMethod.NICE_MOBILE, AuthChannel.PC_WEB,
                AuthPurpose.SIGN_UP, "S1", null, p.providerState(), clock.instant(), clock.instant().plusSeconds(600));
    }

    /** NICE 가 보내는 것과 같은 형식의 콜백 파라미터 생성 (응답은 EUC-KR 로 암호화) */
    private Map<String, String> callback(ProviderPrepareResult p, Map<String, String> result) throws Exception {
        Map<String, String> st = p.providerState();
        Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
        c.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(st.get("nice.key").getBytes(), "AES"),
                new IvParameterSpec(st.get("nice.iv").getBytes()));
        String enc = Base64.getEncoder().encodeToString(c.doFinal(om.writeValueAsString(result).getBytes(NiceCrypto.RESPONSE_CHARSET)));
        NiceCrypto.Keys keys = new NiceCrypto.Keys(st.get("nice.key"), st.get("nice.iv"), st.get("nice.hmac"));
        return new HashMap<>(Map.of("token_version_id", p.correlationKey(), "enc_data", enc,
                "integrity_value", NiceCrypto.hmac(keys, enc)));
    }

    private Map<String, String> successResult(String txId) {
        Map<String, String> r = new HashMap<>();
        r.put("resultcode", "0000");
        r.put("requestno", txId);
        r.put("sitecode", "SITE01");
        r.put("responseno", "NICE-RES-1");
        r.put("name", "홍길동");
        r.put("utf8_name", URLEncoder.encode("홍길동", StandardCharsets.UTF_8));
        r.put("birthdate", "19900101");
        r.put("gender", "1");
        r.put("nationalinfo", "0");
        r.put("mobileco", "1");
        r.put("mobileno", "01012345678");
        r.put("ci", "CI_VALUE");
        r.put("di", "DI_VALUE");
        return r;
    }

    @Test
    void prepare_는_NICE_표준창_form_정보를_만들고_요청데이터를_암호화한다() throws Exception {
        ProviderPrepareResult p = provider.prepare("IDV1", req(AuthChannel.APP), "https://x/cb/nice_mobile");

        assertThat(p.correlationKey()).isEqualTo("TVID-001");
        assertThat(p.formParams()).containsKeys("m", "token_version_id", "enc_data", "integrity_value");

        // 요청 데이터를 복호화해서 내용 확인
        Map<String, String> st = p.providerState();
        NiceCrypto.Keys keys = new NiceCrypto.Keys(st.get("nice.key"), st.get("nice.iv"), st.get("nice.hmac"));
        var json = om.readTree(NiceCrypto.decrypt(keys, p.formParams().get("enc_data"), StandardCharsets.UTF_8));
        assertThat(json.get("requestno").asText()).isEqualTo("IDV1");
        assertThat(json.get("popupyn").asText()).isEqualTo("N");        // APP 채널 → 팝업 아님
        assertThat(json.get("sampleoption").asText()).isEqualTo("Y");   // extra-request-params 반영
    }

    @Test
    void complete_성공시_공통모델로_변환() throws Exception {
        ProviderPrepareResult p = provider.prepare("IDV1", req(AuthChannel.PC_WEB), "cb");
        VerifiedIdentity v = provider.complete(txFrom("IDV1", p), callback(p, successResult("IDV1")));

        assertThat(v.name()).isEqualTo("홍길동");
        assertThat(v.gender()).isEqualTo("M");
        assertThat(v.foreigner()).isFalse();
        assertThat(v.ci()).isEqualTo("CI_VALUE");
        assertThat(v.toString()).doesNotContain("CI_VALUE"); // 로그 마스킹
    }

    @Test
    void 무결성값이_다르면_거부() throws Exception {
        ProviderPrepareResult p = provider.prepare("IDV1", req(AuthChannel.PC_WEB), "cb");
        Map<String, String> cb = callback(p, successResult("IDV1"));
        cb.put("integrity_value", "tampered");
        assertThatThrownBy(() -> provider.complete(txFrom("IDV1", p), cb))
                .extracting(e -> ((IdentityVerificationException) e).getErrorCode())
                .isEqualTo(IdentityErrorCode.INTEGRITY_FAILED);
    }

    @Test
    void 요청번호가_다르면_거부() throws Exception {
        ProviderPrepareResult p = provider.prepare("IDV1", req(AuthChannel.PC_WEB), "cb");
        Map<String, String> cb = callback(p, successResult("OTHER"));
        assertThatThrownBy(() -> provider.complete(txFrom("IDV1", p), cb))
                .extracting(e -> ((IdentityVerificationException) e).getErrorCode())
                .isEqualTo(IdentityErrorCode.REQUEST_NO_MISMATCH);
    }

    @Test
    void 결과코드_실패면_AUTH_FAILED() throws Exception {
        ProviderPrepareResult p = provider.prepare("IDV1", req(AuthChannel.PC_WEB), "cb");
        Map<String, String> r = successResult("IDV1");
        r.put("resultcode", "0001");
        Map<String, String> cb = callback(p, r);
        assertThatThrownBy(() -> provider.complete(txFrom("IDV1", p), cb))
                .extracting(e -> ((IdentityVerificationException) e).getErrorCode())
                .isEqualTo(IdentityErrorCode.AUTH_FAILED);
    }
}
