/**
 * =============================================================================
 *  본인인증 공통 JS (CF-BC-03)  -  /js/common/identity-auth.js
 * -----------------------------------------------------------------------------
 *  업무 화면은 IdentityAuth.open() 한 줄만 호출하면 된다.
 *  인증기관이 NICE 든 사설인증이든 화면 코드는 바뀌지 않는다.
 *
 *  사용 예)
 *    IdentityAuth.open({
 *        method : 'NICE_MOBILE',
 *        channel: 'PC_WEB',              // APP | PC_WEB | RECRUIT_WEB
 *        purpose: 'SIGN_UP',
 *        agreedTerms: ['NICE_PRIVACY', ...],
 *        returnUrl: '/member/join/step2'  // APP 채널만 사용
 *    }).then(function (result) {          // 팝업 채널: 인증 완료 시 resolve
 *        // result = { success, purpose, code, message }
 *    });
 *
 *  동작 순서
 *    1) (팝업 채널) 클릭 즉시 빈 팝업을 먼저 연다  ← 비동기 호출 뒤에 열면 브라우저 팝업차단에 걸림
 *    2) POST /common/identity/start → { actionUrl, httpMethod, formParams, popup }
 *    3) form 을 동적으로 만들어 팝업(또는 현재창)으로 submit
 *    4) 인증 완료 → callback.jsp 가 opener 로 postMessage → 여기서 Promise resolve
 * =============================================================================
 */
(function (window, document) {
    'use strict';

    var POPUP_NAME = 'identityAuthPopup';
    var POPUP_FEATURES = 'width=500,height=650,top=100,left=100,scrollbars=yes,resizable=yes';
    var MESSAGE_TYPE = 'COMMON_IDENTITY_RESULT';

    /** 현재 진행 중인 인증의 resolve 함수 (동시에 1건만 진행) */
    var pendingResolve = null;

    /** 팝업(callback.jsp)에서 보낸 결과 수신 */
    window.addEventListener('message', function (event) {
        // 같은 출처(우리 도메인)에서 온 메시지만 신뢰
        if (event.origin !== window.location.origin) return;
        var data = event.data || {};
        if (data.type !== MESSAGE_TYPE || !pendingResolve) return;
        var resolve = pendingResolve;
        pendingResolve = null;
        resolve(data);
    });

    function submitForm(actionUrl, httpMethod, params, target) {
        var form = document.createElement('form');
        form.method = httpMethod;
        form.action = actionUrl;
        form.target = target;
        form.style.display = 'none';
        Object.keys(params).forEach(function (name) {
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = name;
            input.value = params[name];
            form.appendChild(input);
        });
        document.body.appendChild(form);
        form.submit();
        document.body.removeChild(form);
    }

    function open(options) {
        var isPopupChannel = options.channel !== 'APP';

        // 1) 사용자 클릭 이벤트 안에서 동기적으로 팝업을 먼저 연다 (팝업 차단 회피)
        var popup = null;
        if (isPopupChannel) {
            popup = window.open('about:blank', POPUP_NAME, POPUP_FEATURES);
            if (!popup) {
                return Promise.reject({ success: false, code: 'POPUP_BLOCKED', message: '팝업 차단을 해제해 주세요.' });
            }
        }

        // 2) 인증 시작 API 호출
        return fetch('/common/identity/start', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json' },
            // Spring Security CSRF 사용 시 헤더 추가: 'X-CSRF-TOKEN': token
            body: JSON.stringify({
                method: options.method,
                channel: options.channel,
                purpose: options.purpose,
                returnUrl: options.returnUrl || null,
                agreedTerms: options.agreedTerms || [],
                options: options.options || {}
            })
        }).then(function (res) {
            return res.json().then(function (body) {
                if (!res.ok) throw body;           // { code, message }
                return body;
            });
        }).then(function (start) {
            // 3) 인증창으로 이동
            if (start.popup) {
                submitForm(start.actionUrl, start.httpMethod, start.formParams, POPUP_NAME);
                // 4) 결과 대기 (사용자가 팝업을 그냥 닫는 경우 감지)
                return new Promise(function (resolve) {
                    pendingResolve = resolve;
                    var timer = setInterval(function () {
                        if (popup.closed) {
                            clearInterval(timer);
                            if (pendingResolve === resolve) {
                                pendingResolve = null;
                                resolve({ success: false, code: 'USER_CLOSED', message: '본인인증이 취소되었습니다.' });
                            }
                        }
                    }, 500);
                });
            }
            // APP(WebView): 현재 창에서 이동. 완료 후 서버가 returnUrl 로 보내준다.
            submitForm(start.actionUrl, start.httpMethod, start.formParams, '_self');
            return new Promise(function () {}); // 페이지가 떠나므로 resolve 되지 않음
        }).catch(function (err) {
            if (popup && !popup.closed) popup.close();
            throw err;
        });
    }

    /** 약관 목록 조회 (약관 상세보기 화면 구성용) */
    function getTerms(method) {
        return fetch('/common/identity/terms?method=' + encodeURIComponent(method), { credentials: 'same-origin' })
            .then(function (res) { return res.json(); });
    }

    window.IdentityAuth = { open: open, getTerms: getTerms };
})(window, document);
