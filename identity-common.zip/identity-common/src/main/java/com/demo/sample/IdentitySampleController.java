package com.demo.sample;

import com.demo.common.identity.domain.AuthPurpose;
import com.demo.common.identity.domain.VerifiedIdentity;
import com.demo.common.identity.service.IdentitySessionManager;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Map;

/**
 * [업무 화면 예시] 회원가입 화면이 공통 본인인증을 사용하는 방법.
 *
 * <p>업무 개발자가 해야 할 일은 두 가지뿐이다.
 * <ol>
 *   <li>JSP 에서 공통 JS(IdentityAuth.open) 호출</li>
 *   <li>업무 API 에서 identitySessionManager.require(session, 목적) 로 CI 꺼내 쓰기</li>
 * </ol>
 */
@Controller
public class IdentitySampleController {

    private final IdentitySessionManager identitySessionManager;

    public IdentitySampleController(IdentitySessionManager identitySessionManager) {
        this.identitySessionManager = identitySessionManager;
    }

    /** 샘플 화면 (WEB-INF/views/sample/identity-sample.jsp) */
    @GetMapping("/sample/identity")
    public String page() {
        return "sample/identity-sample";
    }

    /**
     * 회원가입 처리 예시.
     * 본인인증을 안 했거나 만료됐으면 require() 가 IDV-301 예외 → IdentityApiExceptionHandler 가 401 응답.
     */
    @PostMapping("/sample/join")
    @ResponseBody
    public Map<String, Object> join(HttpSession session) {
        VerifiedIdentity idv = identitySessionManager.require(session, AuthPurpose.SIGN_UP);

        // TODO 실제 업무: 동일 CI 기가입 여부 확인 → 회원 저장(CI 는 암호화 컬럼에 저장)
        // memberService.join(form, idv.ci(), idv.di(), idv.mobileNo());

        // 인증결과는 1회 사용 후 제거 (같은 인증으로 중복 가입 방지)
        identitySessionManager.clear(session, AuthPurpose.SIGN_UP);
        return Map.of("result", "OK", "name", idv.toMaskedView().name());
    }
}
