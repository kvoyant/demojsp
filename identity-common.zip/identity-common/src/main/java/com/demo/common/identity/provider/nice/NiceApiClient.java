package com.demo.common.identity.provider.nice;

import com.demo.common.identity.config.IdentityProperties;
import com.demo.common.identity.exception.IdentityErrorCode;
import com.demo.common.identity.exception.IdentityVerificationException;
import com.fasterxml.jackson.databind.JsonNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.nio.charset.StandardCharsets;
import java.time.Clock;
import java.util.Base64;
import java.util.Map;

/**
 * NICE API 서버(svc.niceapi.co.kr) 호출 전담 클라이언트.
 *
 * <p>HTTP 통신만 담당하고 암호화/흐름 제어는 하지 않는다. (단일 책임)
 * <ol>
 *   <li>기관토큰(access_token) 발급 - OAuth client_credentials, 최초 1회 후 캐시</li>
 *   <li>암호화 토큰(token_val) 발급 - 인증 요청 건마다 호출</li>
 * </ol>
 *
 * <p>mock-enabled=true 인 로컬 환경에서는 빈이 생성되지 않는다.
 */
@Component
@ConditionalOnProperty(prefix = "common.identity", name = "mock-enabled", havingValue = "false", matchIfMissing = true)
public class NiceApiClient {

    private static final Logger log = LoggerFactory.getLogger(NiceApiClient.class);

    /** NICE 응답 성공 코드 (dataHeader.GW_RSLT_CD / dataBody.rsp_cd / dataBody.result_cd) */
    private static final String GW_SUCCESS = "1200";
    private static final String RSP_SUCCESS = "P000";
    private static final String RESULT_SUCCESS = "0000";

    private final RestClient niceRestClient;
    private final IdentityProperties.Nice props;
    private final Clock clock;

    /** 발급된 기관토큰 메모리 캐시 (volatile: 멀티스레드 가시성 보장) */
    private volatile String cachedAccessToken;

    public NiceApiClient(RestClient niceRestClient, IdentityProperties properties, Clock identityClock) {
        this.niceRestClient = niceRestClient;
        this.props = properties.getNice();
        this.clock = identityClock;
        this.cachedAccessToken = props.getAccessToken(); // 설정에 미리 발급받은 토큰이 있으면 그대로 사용
    }

    /** 암호화 토큰 발급 결과 */
    public record CryptoToken(String siteCode, String tokenVersionId, String tokenVal) {
        @Override
        public String toString() {
            return "CryptoToken[siteCode=" + siteCode + ", tokenVersionId=" + tokenVersionId + ", tokenVal=****]";
        }
    }

    /**
     * 암호화 토큰 발급.
     *
     * @param reqDtim 요청일시 (yyyyMMddHHmmss) - 키 생성에 그대로 다시 쓰이므로 호출측과 동일 값이어야 함
     * @param reqNo   요청고유번호 (거래번호, 최대 30byte)
     */
    public CryptoToken requestCryptoToken(String reqDtim, String reqNo) {
        Map<String, Object> body = Map.of(
                "dataHeader", Map.of("CNTY_CD", "ko"),
                "dataBody", Map.of(
                        "req_dtim", reqDtim,
                        "req_no", reqNo,
                        "enc_mode", "1"   // 1: AES128/CBC/PKCS7 (가이드 기준)
                ));

        JsonNode res = post(props.getCryptoTokenPath(), cryptoAuthorization(), body);
        JsonNode dataBody = res.path("dataBody");

        // 응답코드 3단 검증: 게이트웨이 → 응답 → 결과
        String gw = res.path("dataHeader").path("GW_RSLT_CD").asText();
        String rsp = dataBody.path("rsp_cd").asText();
        String result = dataBody.path("result_cd").asText();
        if (!GW_SUCCESS.equals(gw) || !RSP_SUCCESS.equals(rsp) || !RESULT_SUCCESS.equals(result)) {
            throw new IdentityVerificationException(IdentityErrorCode.PROVIDER_ERROR,
                    "crypto token failed gw=" + gw + ", rsp=" + rsp + ", result=" + result);
        }
        return new CryptoToken(
                dataBody.path("site_code").asText(),
                dataBody.path("token_version_id").asText(),
                dataBody.path("token_val").asText());
    }

    /**
     * 기관토큰 조회 (없으면 발급).
     * <p>synchronized + double-check: 기동 직후 동시 요청이 몰려도 발급 API 는 1회만 호출되도록 한다.
     * <p>다중 서버 환경에서는 각 서버가 1회씩 발급하게 되므로, 운영에서는 미리 발급한 토큰을
     * 설정(access-token)으로 주입하거나 DB/Redis 에 공유 저장하는 것을 권장.
     */
    String getAccessToken() {
        String token = cachedAccessToken;
        if (StringUtils.hasText(token)) {
            return token;
        }
        synchronized (this) {
            if (!StringUtils.hasText(cachedAccessToken)) {
                cachedAccessToken = issueAccessToken();
                log.info("[NICE] access token issued");
            }
            return cachedAccessToken;
        }
    }

    /** 기관토큰 발급: Authorization: Basic Base64(client_id:client_secret) */
    private String issueAccessToken() {
        String basic = Base64.getEncoder().encodeToString(
                (props.getClientId() + ":" + props.getClientSecret()).getBytes(StandardCharsets.UTF_8));
        try {
            JsonNode res = niceRestClient.post()
                    .uri(props.getTokenPath())
                    .header("Authorization", "Basic " + basic)
                    .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                    .body("grant_type=client_credentials&scope=default")
                    .retrieve()
                    .body(JsonNode.class);
            String token = res == null ? null : res.path("dataBody").path("access_token").asText(null);
            if (!StringUtils.hasText(token)) {
                throw new IdentityVerificationException(IdentityErrorCode.PROVIDER_ERROR, "access token empty");
            }
            return token;
        } catch (RestClientException e) {
            throw new IdentityVerificationException(IdentityErrorCode.PROVIDER_ERROR, "access token request failed", e);
        }
    }

    /**
     * 암호화 토큰 API 인증 헤더:
     * {@code bearer Base64(access_token:현재타임스탬프(초):client_id)}
     */
    private String cryptoAuthorization() {
        long epochSec = clock.instant().getEpochSecond();
        String raw = getAccessToken() + ":" + epochSec + ":" + props.getClientId();
        return "bearer " + Base64.getEncoder().encodeToString(raw.getBytes(StandardCharsets.UTF_8));
    }

    private JsonNode post(String path, String authorization, Object body) {
        try {
            JsonNode res = niceRestClient.post()
                    .uri(path)
                    .header("Authorization", authorization)
                    .header("ProductID", props.getProductId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(body)
                    .retrieve()
                    .body(JsonNode.class);
            if (res == null) {
                throw new IdentityVerificationException(IdentityErrorCode.PROVIDER_ERROR, "empty response: " + path);
            }
            return res;
        } catch (RestClientException e) {
            // 타임아웃/네트워크 오류 등. 원인은 로그로, 화면에는 공통 메시지
            throw new IdentityVerificationException(IdentityErrorCode.PROVIDER_ERROR, "NICE api call failed: " + path, e);
        }
    }
}
