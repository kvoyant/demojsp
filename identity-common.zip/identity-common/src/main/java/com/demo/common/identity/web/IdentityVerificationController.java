package com.demo.common.identity.web;

import com.demo.common.identity.domain.AuthMethod;
import com.demo.common.identity.domain.AuthPurpose;
import com.demo.common.identity.domain.IdentityTx;
import com.demo.common.identity.domain.StartRequest;
import com.demo.common.identity.domain.StartResponse;
import com.demo.common.identity.domain.TermsDocument;
import com.demo.common.identity.domain.VerifiedIdentity;
import com.demo.common.identity.exception.IdentityErrorCode;
import com.demo.common.identity.exception.IdentityVerificationException;
import com.demo.common.identity.service.IdentityProviderRegistry;
import com.demo.common.identity.service.IdentitySessionManager;
import com.demo.common.identity.service.IdentityVerificationService;
import com.demo.common.identity.service.TermsService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * 본인인증 공통 컨트롤러 - 모든 채널(APP / PC WEB / 모집인WEB)이 같은 URL 을 사용한다.
 *
 * <pre>
 *  GET  /common/identity/methods              사용 가능한 인증수단 목록
 *  GET  /common/identity/terms?method=...     인증수단별 약관 목록 (약관 상세보기)
 *  POST /common/identity/start                인증 시작 → 인증창 form 정보 반환 (JSON)
 *  GET|POST /common/identity/callback/{m}     인증기관 결과 수신 → 결과 전달 JSP
 *  GET  /common/identity/result?purpose=...   인증 결과 확인 (마스킹, CI 미포함)
 * </pre>
 *
 * <p>컨트롤러는 HTTP 변환만 하고 로직은 {@link IdentityVerificationService} 에 위임한다.
 * <p>※ Spring Security 사용 시 callback 경로는 CSRF 예외 + permitAll 처리 필요 (외부 도메인에서 호출됨).
 */
@Controller
@RequestMapping("/common/identity")
public class IdentityVerificationController {

    private static final Logger log = LoggerFactory.getLogger(IdentityVerificationController.class);

    /** 결과 전달 JSP (WEB-INF/views/common/identity/callback.jsp) */
    static final String CALLBACK_VIEW = "common/identity/callback";

    private final IdentityVerificationService identityService;
    private final IdentityProviderRegistry registry;
    private final TermsService termsService;
    private final IdentitySessionManager sessionManager;

    public IdentityVerificationController(IdentityVerificationService identityService,
                                          IdentityProviderRegistry registry,
                                          TermsService termsService,
                                          IdentitySessionManager sessionManager) {
        this.identityService = identityService;
        this.registry = registry;
        this.termsService = termsService;
        this.sessionManager = sessionManager;
    }

    @GetMapping("/methods")
    @ResponseBody
    public Set<AuthMethod> methods() {
        return registry.availableMethods();
    }

    @GetMapping("/terms")
    @ResponseBody
    public List<TermsDocument> terms(@RequestParam AuthMethod method) {
        return termsService.getTerms(method);
    }

    /**
     * 인증 시작.
     * <p>세션이 없으면 생성한다(getSession(true)) - 콜백 시 "같은 브라우저인지" 검증하는 기준이 된다.
     */
    @PostMapping("/start")
    @ResponseBody
    public StartResponse start(@Valid @RequestBody StartRequest request, HttpServletRequest httpRequest) {
        return identityService.start(request, httpRequest.getSession(true));
    }

    /**
     * 인증기관 콜백.
     * <p>NICE methodtype 이 get/post 어느 쪽이든 받을 수 있도록 두 메서드 모두 허용.
     * <p>이 메서드는 예외를 밖으로 던지지 않는다. 성공/실패 모두 JSP 로 렌더링해서
     * 팝업이면 부모창에 결과를 알리고 닫고, APP 이면 returnUrl 로 이동시킨다.
     */
    @RequestMapping(value = "/callback/{method}", method = {RequestMethod.GET, RequestMethod.POST})
    public String callback(@PathVariable("method") String methodPath,
                           @RequestParam Map<String, String> params,
                           HttpServletRequest httpRequest,
                           Model model) {
        IdentityTx tx = null;
        try {
            AuthMethod method = AuthMethod.valueOf(methodPath.toUpperCase(Locale.ROOT));
            IdentityVerificationService.Completion done = identityService.complete(method, params, httpRequest);
            tx = done.tx();
            fillModel(model, tx, true, null);
        } catch (IdentityVerificationService.TxAwareException e) {
            tx = e.getTx();
            fillModel(model, tx, false, e.getErrorCode());
        } catch (IdentityVerificationException e) {
            // 거래를 못 찾은 경우 등 - 채널을 알 수 없으므로 팝업 기본으로 처리
            log.warn("[Identity] callback failed: {}", e.getMessage());
            fillModel(model, null, false, e.getErrorCode());
        } catch (IllegalArgumentException e) {
            fillModel(model, null, false, IdentityErrorCode.UNSUPPORTED_METHOD);
        }
        return CALLBACK_VIEW;
    }

    /**
     * 인증 결과 조회 (화면에서 "인증 완료 상태" 표시용).
     * <p>CI/DI 는 절대 화면에 내리지 않는다 → 업무 API 에서 서버 세션으로 직접 사용.
     */
    @GetMapping("/result")
    @ResponseBody
    public ResponseEntity<VerifiedIdentity.MaskedView> result(@RequestParam AuthPurpose purpose, HttpSession session) {
        return sessionManager.find(session, purpose)
                .map(v -> ResponseEntity.ok(v.toMaskedView()))
                .orElseGet(() -> ResponseEntity.noContent().build());
    }

    /** callback.jsp 에서 사용하는 모델. JSP 는 이 값만 보고 분기한다. */
    private void fillModel(Model model, IdentityTx tx, boolean success, IdentityErrorCode error) {
        model.addAttribute("success", success);
        model.addAttribute("popup", tx == null || tx.channel().isPopup());
        model.addAttribute("purpose", tx == null ? "" : tx.purpose().name());
        model.addAttribute("returnUrl", tx == null ? null : tx.returnUrl());
        model.addAttribute("errorCode", error == null ? "" : error.getCode());
        model.addAttribute("errorMessage", error == null ? "" : error.getMessage());
    }
}
