package com.demo.common.identity.config;

import com.demo.common.identity.domain.AuthMethod;
import com.demo.common.identity.domain.TermsDocument;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.time.Duration;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 본인인증 공통모듈 설정 (application.yml 의 {@code common.identity.*}).
 *
 * <p>환경(local/dev/prd)별로 달라지는 값은 모두 여기로 모았다. 소스 수정 없이 yml 만으로 전환 가능.
 * clientSecret 같은 비밀값은 yml 에 평문으로 두지 말고 환경변수/Vault/Jasypt 로 주입한다.
 */
@ConfigurationProperties(prefix = "common.identity")
public class IdentityProperties {

    /** 서비스 외부 기준 URL (콜백 URL 생성용). 예: https://www.example.com  - LB/프록시 뒤에 있을 때 필수 */
    private String baseUrl = "http://localhost:8080";

    /** 공통 콜백 경로. 실제 URL = baseUrl + callbackPath + "/" + method */
    private String callbackPath = "/common/identity/callback";

    /** 인증 거래 유효시간 (인증창 열고 완료까지 허용 시간) */
    private Duration txTtl = Duration.ofMinutes(10);

    /** 세션에 저장된 인증 결과의 유효시간 (업무 처리 완료까지 허용 시간) */
    private Duration resultTtl = Duration.ofMinutes(30);

    /** APP 채널 returnUrl 허용 prefix 목록 (오픈 리다이렉트 방지). 예: "/", "myapp://" */
    private List<String> allowedReturnUrlPrefixes = new ArrayList<>(List.of("/"));

    /**
     * Mock Provider 사용 여부. true 면 NICE 실제 연동 대신 가짜 인증으로 즉시 완료된다.
     * <b>local/개발 PC 전용. 운영에서 true 면 기동 시 실패하도록 프로젝트 공통 체크를 추가할 것.</b>
     */
    private boolean mockEnabled = false;

    /** 인증수단별 약관 목록 (약관 상세보기 / 필수동의 검증용) */
    private Map<AuthMethod, List<TermsDocument>> terms = new EnumMap<>(AuthMethod.class);

    /** NICE ID 설정 */
    private final Nice nice = new Nice();

    /**
     * NICE ID(통합인증) 연동 설정.
     *
     * <p>기본값은 NICE 개발가이드(API 방식, 2023~) 기준이다.
     * <b>URL/파라미터는 계약 시 수령한 최신 가이드와 반드시 대조할 것.</b>
     */
    public static class Nice {
        /** NICE 발급 Client ID */
        private String clientId;
        /** NICE 발급 Client Secret (외부 주입 필수) */
        private String clientSecret;
        /** NICE 발급 상품 ID (본인인증 상품) */
        private String productId;
        /**
         * Access Token. NICE 기관토큰은 유효기간이 매우 길어(가이드 기준 약 50년) 최초 1회 발급 후 보관해 쓰는 것이 일반적.
         * 값이 있으면 그대로 사용하고, 비어 있으면 기동 후 최초 호출 시 발급하여 메모리에 캐시한다.
         */
        private String accessToken;
        /** NICE API 서버 */
        private String apiBaseUrl = "https://svc.niceapi.co.kr:22001";
        /** 기관토큰 발급 경로 */
        private String tokenPath = "/digital/niceid/oauth/oauth/token";
        /** 암호화 토큰 발급 경로 */
        private String cryptoTokenPath = "/digital/niceid/api/v1.0/common/crypto/token";
        /** 표준창(인증창) URL */
        private String checkplusUrl = "https://nice.checkplus.co.kr/CheckPlusSafeModel/service.cb";
        /** 인증 유형. M:휴대폰 (가이드상 다른 값: C 카드, X 공동인증서 등 - 상품 계약에 따름) */
        private String authType = "M";
        /**
         * 결과 전달 방식 (get/post).
         * <p><b>기본 get 권장</b>: NICE 도메인에서 우리 콜백으로 cross-site POST 가 오면
         * 브라우저 SameSite=Lax 정책 때문에 세션 쿠키가 전송되지 않아 세션 검증이 실패한다.
         * post 를 쓰려면 세션 쿠키를 SameSite=None; Secure 로 설정해야 한다.
         */
        private String methodType = "get";
        /** 팝업 여부(Y/N). 실제 값은 채널(팝업/WebView)에 따라 Provider 에서 결정하고, 여기는 기본값. */
        private String popupYn = "Y";
        /** API 연결/응답 타임아웃 */
        private Duration connectTimeout = Duration.ofSeconds(3);
        private Duration readTimeout = Duration.ofSeconds(5);
        /**
         * 요청 데이터에 추가할 파라미터 (NICE 요청 JSON 에 그대로 merge).
         * <p>요구사항의 "통신사 미지정 방식", "MO인증 결합 시 번호입력 생략" 은 NICE 상품/옵션 계약 사항이므로
         * 가이드에 명시된 파라미터명/값을 여기 설정해서 반영한다. (소스 수정 불필요)
         */
        private Map<String, String> extraRequestParams = new LinkedHashMap<>();

        // ---- getter / setter ----
        public String getClientId() { return clientId; }
        public void setClientId(String clientId) { this.clientId = clientId; }
        public String getClientSecret() { return clientSecret; }
        public void setClientSecret(String clientSecret) { this.clientSecret = clientSecret; }
        public String getProductId() { return productId; }
        public void setProductId(String productId) { this.productId = productId; }
        public String getAccessToken() { return accessToken; }
        public void setAccessToken(String accessToken) { this.accessToken = accessToken; }
        public String getApiBaseUrl() { return apiBaseUrl; }
        public void setApiBaseUrl(String apiBaseUrl) { this.apiBaseUrl = apiBaseUrl; }
        public String getTokenPath() { return tokenPath; }
        public void setTokenPath(String tokenPath) { this.tokenPath = tokenPath; }
        public String getCryptoTokenPath() { return cryptoTokenPath; }
        public void setCryptoTokenPath(String cryptoTokenPath) { this.cryptoTokenPath = cryptoTokenPath; }
        public String getCheckplusUrl() { return checkplusUrl; }
        public void setCheckplusUrl(String checkplusUrl) { this.checkplusUrl = checkplusUrl; }
        public String getAuthType() { return authType; }
        public void setAuthType(String authType) { this.authType = authType; }
        public String getMethodType() { return methodType; }
        public void setMethodType(String methodType) { this.methodType = methodType; }
        public String getPopupYn() { return popupYn; }
        public void setPopupYn(String popupYn) { this.popupYn = popupYn; }
        public Duration getConnectTimeout() { return connectTimeout; }
        public void setConnectTimeout(Duration connectTimeout) { this.connectTimeout = connectTimeout; }
        public Duration getReadTimeout() { return readTimeout; }
        public void setReadTimeout(Duration readTimeout) { this.readTimeout = readTimeout; }
        public Map<String, String> getExtraRequestParams() { return extraRequestParams; }
        public void setExtraRequestParams(Map<String, String> extraRequestParams) { this.extraRequestParams = extraRequestParams; }
    }

    // ---- getter / setter ----
    public String getBaseUrl() { return baseUrl; }
    public void setBaseUrl(String baseUrl) { this.baseUrl = baseUrl; }
    public String getCallbackPath() { return callbackPath; }
    public void setCallbackPath(String callbackPath) { this.callbackPath = callbackPath; }
    public Duration getTxTtl() { return txTtl; }
    public void setTxTtl(Duration txTtl) { this.txTtl = txTtl; }
    public Duration getResultTtl() { return resultTtl; }
    public void setResultTtl(Duration resultTtl) { this.resultTtl = resultTtl; }
    public List<String> getAllowedReturnUrlPrefixes() { return allowedReturnUrlPrefixes; }
    public void setAllowedReturnUrlPrefixes(List<String> v) { this.allowedReturnUrlPrefixes = v; }
    public boolean isMockEnabled() { return mockEnabled; }
    public void setMockEnabled(boolean mockEnabled) { this.mockEnabled = mockEnabled; }
    public Map<AuthMethod, List<TermsDocument>> getTerms() { return terms; }
    public void setTerms(Map<AuthMethod, List<TermsDocument>> terms) { this.terms = terms; }
    public Nice getNice() { return nice; }
}
