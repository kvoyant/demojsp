package com.demo.common.identity.config;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.client.RestClient;

import java.time.Clock;

/**
 * 본인인증 공통모듈 빈 설정.
 *
 * <p>업무 애플리케이션은 이 패키지(com.demo.common.identity)가 컴포넌트 스캔 범위에 들어가기만 하면 된다.
 * 별도 jar 로 배포할 경우 META-INF/spring/...AutoConfiguration.imports 에 등록하여 자동설정으로 전환 가능.
 */
@Configuration
@EnableScheduling   // InMemoryIdentityTxStore 만료 거래 정리용
@EnableConfigurationProperties(IdentityProperties.class)
public class IdentityConfig {

    /**
     * NICE API 호출 전용 RestClient.
     * <p>타임아웃을 반드시 지정한다. (미지정 시 인증기관 장애가 WAS 스레드 고갈로 번질 수 있음)
     */
    @Bean
    public RestClient niceRestClient(IdentityProperties props) {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout((int) props.getNice().getConnectTimeout().toMillis());
        factory.setReadTimeout((int) props.getNice().getReadTimeout().toMillis());
        return RestClient.builder()
                .baseUrl(props.getNice().getApiBaseUrl())
                .requestFactory(factory)
                .build();
    }

    /** 시간 의존 로직(만료 검증) 테스트를 위해 Clock 을 빈으로 주입 */
    @Bean
    public Clock identityClock() {
        return Clock.systemDefaultZone();
    }
}
