package com.demo.common.identity.web;

import com.demo.common.identity.exception.IdentityVerificationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Map;

/**
 * 본인인증 JSON API 오류 응답 표준화.
 *
 * <p>업무 컨트롤러에서 {@code identitySessionManager.require()} 가 던지는 NOT_VERIFIED 도 여기서 처리되어
 * 화면은 {@code code == "IDV-301"} 을 보고 본인인증 화면으로 유도하면 된다.
 * <p>프로젝트 공통 ExceptionHandler 가 있다면 그쪽으로 통합하고 이 클래스는 삭제해도 된다.
 */
@RestControllerAdvice
public class IdentityApiExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(IdentityApiExceptionHandler.class);

    @ExceptionHandler(IdentityVerificationException.class)
    public ResponseEntity<Map<String, String>> handle(IdentityVerificationException e) {
        log.warn("[Identity] {} detail={}", e.getErrorCode().getCode(), e.getDetail(), e.getCause());
        return ResponseEntity.status(e.getErrorCode().getStatus())
                .body(Map.of("code", e.getErrorCode().getCode(), "message", e.getErrorCode().getMessage()));
    }
}
