<%--
  [업무 화면 예시] 회원가입 - 본인인증 단계
  공통 JS 하나(identity-auth.js)만 포함하고 IdentityAuth.open() 을 호출한다.
  local 프로필(mock-enabled=true)에서는 NICE 없이 즉시 인증 완료된다.
--%>
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>본인인증 공통모듈 샘플</title>
    <style>
        body { font-family: sans-serif; max-width: 560px; margin: 32px auto; padding: 0 16px; }
        li { margin: 6px 0; }
        button { padding: 8px 16px; margin-right: 8px; }
        pre { background: #f4f4f4; padding: 12px; white-space: pre-wrap; }
    </style>
</head>
<body>
<h2>회원가입 - 휴대폰 본인인증</h2>

<label>채널
    <select id="channel">
        <option value="PC_WEB">PC WEB (팝업)</option>
        <option value="RECRUIT_WEB">모집인WEB (팝업)</option>
        <option value="APP">APP (페이지 이동)</option>
    </select>
</label>

<h4>약관 동의</h4>
<label><input type="checkbox" id="agreeAll"> 전체 동의</label>
<ul id="terms"></ul>

<button id="btnAuth">휴대폰 본인인증</button>
<button id="btnJoin">가입하기</button>
<pre id="log"></pre>

<script src="/js/common/identity-auth.js"></script>
<script>
(function () {
    var METHOD = 'NICE_MOBILE', PURPOSE = 'SIGN_UP';
    var logEl = document.getElementById('log');
    function log(o) { logEl.textContent = typeof o === 'string' ? o : JSON.stringify(o, null, 2); }

    // 1) 약관 목록 + 상세보기 링크
    IdentityAuth.getTerms(METHOD).then(function (terms) {
        var ul = document.getElementById('terms');
        terms.forEach(function (t) {
            var li = document.createElement('li');
            li.innerHTML = '<label><input type="checkbox" name="terms"> </label> <a target="_blank">[보기]</a>';
            var cb = li.querySelector('input');
            cb.value = t.code;
            li.querySelector('label').append((t.required ? '[필수] ' : '[선택] ') + t.title);
            li.querySelector('a').href = t.contentUrl;   // 약관 상세보기
            ul.appendChild(li);
        });
    });
    document.getElementById('agreeAll').addEventListener('change', function (e) {
        document.querySelectorAll('input[name=terms]').forEach(function (cb) { cb.checked = e.target.checked; });
    });

    // 2) 본인인증 (반드시 클릭 이벤트 안에서 호출 → 팝업 차단 회피)
    document.getElementById('btnAuth').addEventListener('click', function () {
        var agreed = Array.prototype.map.call(document.querySelectorAll('input[name=terms]:checked'), function (cb) { return cb.value; });
        IdentityAuth.open({
            method: METHOD,
            channel: document.getElementById('channel').value,
            purpose: PURPOSE,
            agreedTerms: agreed,
            returnUrl: '/sample/identity'
        }).then(function (result) {
            log(result);
            if (result.success) refreshResult();
        }).catch(log);
    });

    // 3) 인증 결과 조회 (마스킹된 값만 내려옴)
    function refreshResult() {
        fetch('/common/identity/result?purpose=' + PURPOSE, { credentials: 'same-origin' })
            .then(function (r) { return r.status === 204 ? '인증 결과 없음' : r.json(); })
            .then(log);
    }

    // 4) 업무 API 호출 - 서버가 세션의 인증결과(CI)를 직접 사용
    document.getElementById('btnJoin').addEventListener('click', function () {
        fetch('/sample/join', { method: 'POST', credentials: 'same-origin' })
            .then(function (r) { return r.json(); }).then(log);
    });

    // APP 채널로 돌아온 경우 (?identityResult=success)
    if (location.search.indexOf('identityResult=') >= 0) refreshResult();
})();
</script>
</body>
</html>
